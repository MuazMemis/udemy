# Bootsrap Proje Şablonu

```sh
npm run scss
```
